<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Entrust\\Providers\\EntrustServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Entrust\\Providers\\EntrustServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);