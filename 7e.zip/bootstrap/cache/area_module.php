<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Area\\Providers\\AreaServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Area\\Providers\\AreaServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);