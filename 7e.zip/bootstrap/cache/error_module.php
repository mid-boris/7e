<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Error\\Providers\\ErrorServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Error\\Providers\\ErrorServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);