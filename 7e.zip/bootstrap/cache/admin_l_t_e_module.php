<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminLTE\\Providers\\AdminLTEServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminLTE\\Providers\\AdminLTEServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);