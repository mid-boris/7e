<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Node\\Providers\\NodeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Node\\Providers\\NodeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);