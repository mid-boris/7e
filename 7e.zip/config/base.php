<?php

return [
    'name' => 'Base',
    'perpage' => 50,
    'domain' => config('app.url'),
    'uri_prefix' => '/api',
];
