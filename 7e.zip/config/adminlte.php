<?php

return [
    'name' => 'AdminLTE'
];
