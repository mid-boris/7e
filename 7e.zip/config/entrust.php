<?php

return [
    'name' => 'Entrust'
];
