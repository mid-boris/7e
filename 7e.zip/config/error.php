<?php

return [
    'name' => 'Error'
];
