<?php

return [
    'name' => 'Template'
];
