<?php

return [
    'name' => 'Area'
];
