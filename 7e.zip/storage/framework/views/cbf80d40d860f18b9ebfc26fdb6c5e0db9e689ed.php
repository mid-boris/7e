<?php $__env->startSection('title', 'Index'); ?>
<?php echo $__env->make('template::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>