<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('adminlte::include.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <header class="main-header">
        <?php echo $__env->make('template::include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <aside class="main-sidebar">
        <?php echo $__env->make('template::include.side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </aside>
    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="main-footer">
        <?php echo $__env->make('adminlte::include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>
    <aside class="control-sidebar control-sidebar-dark">
        <?php echo $__env->make('adminlte::include.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </aside>
    <div class="control-sidebar-bg"></div>
</div>
<?php echo $__env->make('adminlte::include.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template::include.helper', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template::include.globalScript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template::include.layoutScript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
