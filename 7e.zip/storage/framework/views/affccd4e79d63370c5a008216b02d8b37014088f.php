<?php echo $__env->make('adminlte::include.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template::include.globalScript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(function () {
        $.get(
            apiDomain + '/1.0/entrust/isLogin',
            function (res) {
                if (res.data) {
                    url = domain + '/home';
                } else {
                    url = domain + '/login';
                }
                window.location.href = url;
            },
        );
    });
</script>