<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" id="menu" data-widget="tree">
        <li class="header">DASHBOARD GROUP</li>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($datum->children)): ?>
                <li class="treeview">
            <?php else: ?>
                <li>
            <?php endif; ?>
                    <a href="#">
                        <i class="fa <?php echo e($datum->icon_class); ?>"></i> <span><?php echo e($datum->name); ?></span>
                        <span class="pull-right-container"></span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <?php if(isset($datum->children)): ?>
                        <ul class="treeview-menu">
                        <?php $__currentLoopData = $datum->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li name="<?php echo e($child->name); ?>"><a href="<?php echo e($child->uri ?? '#'); ?>"><i class="fa <?php echo e($child->icon_class); ?>"></i> <?php echo e($child->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            
                
                
              
            
            
            
                
                
            
        
        
            
                
                
                
              
            
            
            
                
                
                
                
            
        
        
            
                
                
              
            
            
        
        
            
                
                
                
              
            
            
            
                
                
                
                
            
        
        
            
                
                
                
              
            
            
            
                
                
                
                
                
                
            
        
        
            
                
                
              
            
            
            
                
                
                
            
        
        
            
                
                
              
            
            
            
                
                
            
        
        
            
                
                
              
              
            
            
        
        
            
                
                
              
              
              
            
            
        
        
            
                
                
              
            
            
            
                
                
                
                
                
                
                
                
                
            
        
        
            
                
                
              
            
            
            
                
                
                    
                        
                  
                
                    
                    
                        
                        
                            
                                
                      
                    
                            
                            
                                
                                
                            
                        
                    
                
                
            
        
        
        
        
        
        
    </ul>
</section>
<!-- /.sidebar -->