<?php $__env->startSection('title', 'Permission'); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1 id="pageTitle" name="地區管理">
            地區管理
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> 首頁</a></li>
            <li class="active">地區管理</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">地區</h3>
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#areaCreateModal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> 新增</button>
            </div>
            <div class="box-body table-responsive">
                <table class="table table-hover trToggleCheckbox col-md-4">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>名稱</th>
                        <th>狀態</th>
                        <th></th>
                        <th>最後修改時間</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr area='<?php echo json_encode($item, 15, 512) ?>'>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><a href="/area?id=<?php echo e($item->id); ?>&name=<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></td>
                            <td><?php echo e($item->status == 0 ? 'X' : 'V'); ?></td>
                            <th><button type="button" class="btn btn-default" data-toggle="modal" data-target="#areaEditModal">修改</button></th>
                            <td><?php echo e($item->updated_at); ?></td>
                            <td>
                                <form method="get" action="/area/delete">
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                    <button type="submit" class="btn btn-danger">刪除</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="box-footer">
                <?php echo $area->appends($parameter)->render(); ?>

            </div>
        </div>
    </section>

    <div class="modal fade" id="areaCreateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">新增地區</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="">
                        <form class="form-horizontal" method="post" action="/area/create">
                            <div class="box-body">
                                <div class="form-group">
                                    <label for="inputEmail3" class="col-sm-2 control-label">名稱</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" placeholder="Name" name="name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword3" class="col-sm-2 control-label">上層名稱</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="parent_name" placeholder="<?php echo e($name); ?>" readonly value="<?php echo e($name); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword3" class="col-sm-2 control-label"></label>
                                    <div class="col-sm-10 checkbox">
                                        <label>
                                            <input name="status" type="checkbox" id="statusChk" value="1" checked>
                                            啟用
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                                <button type="submit" class="btn btn-primary pull-right">送出</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="areaEditModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">編輯地區</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="">
                        <form class="form-horizontal" method="post" action="/area/update">
                            <div class="box-body">
                                <div class="form-group">
                                    <label for="inputEmail3" class="col-sm-2 control-label">名稱</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" placeholder="Name" name="name">
                                        <input type="hidden" name="id">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword3" class="col-sm-2 control-label">上層名稱</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" placeholder="<?php echo e($name); ?>" readonly value="">
                                        <input type="hidden" name="parent_id" value="<?php echo e($id); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword3" class="col-sm-2 control-label"></label>
                                    <div class="col-sm-10 checkbox">
                                        <label>
                                            <input name="status" type="checkbox" id="statusChk" value="1" checked>
                                            啟用
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                                <button type="submit" class="btn btn-primary pull-right">送出</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#areaEditModal').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget);
                var area = JSON.parse(button.parent().parent().attr('area'));
                var modal = $(this);
                modal.find('.modal-body input[name="id"]').val(area.id);
                modal.find('.modal-body input[name="name"]').val(area.name);
                $(':checkbox', modal).prop("checked", area.status);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>