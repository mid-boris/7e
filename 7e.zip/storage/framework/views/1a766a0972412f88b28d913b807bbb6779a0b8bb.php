<!DOCTYPE html>
<html>
    <head>
        <?php echo $__env->make('adminlte::layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <header class="main-header">
            <?php echo $__env->make('adminlte::layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </header>
        <aside class="main-sidebar">
            <?php echo $__env->make('adminlte::layouts.side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </aside>
        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    Dashboard
                    <small>Control panel</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">Dashboard</li>
                </ol>
            </section>
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>
        <footer class="main-footer">
            <?php echo $__env->make('adminlte::layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </footer>
        <aside class="control-sidebar control-sidebar-dark">
            <?php echo $__env->make('adminlte::layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </aside>
        <div class="control-sidebar-bg"></div>
    </div>
    <?php echo $__env->make('adminlte::layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>
