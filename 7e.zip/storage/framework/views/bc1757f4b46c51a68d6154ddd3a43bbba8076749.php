<?php $__env->startSection('title', 'Permission'); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1 id="pageTitle" name="帳號管理">
            帳號管理
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> 首頁</a></li>
            <li class="active">帳號管理</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">帳號</h3>
            </div>
            <div class="box-body table-responsive">
                <table class="table table-hover trToggleCheckbox">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>帳號</th>
                        <th>暱稱</th>
                        <th>角色</th>
                        <th></th>
                        <th>最後修改時間</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr nodeId="<?php echo e($item->id); ?>">
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><?php echo e($item->account); ?></td>
                            <td><?php echo e($item->nick_name); ?></td>
                            <td><?php echo e($item->role->count() ? $item->role[0]->name : 'Non'); ?></td>
                            <th><button type="submit" class="btn btn-default">修改</button></th>
                            <td><?php echo e($item->updated_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>