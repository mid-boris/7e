<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template::layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>