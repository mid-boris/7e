@extends('template::layouts.master')

@section('title', 'Index')