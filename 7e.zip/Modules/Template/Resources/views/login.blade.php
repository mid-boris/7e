@extends('template::layouts.login')

@section('script')
    <script>
        $(function () {
        });
    </script>
@endsection