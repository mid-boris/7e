<?php

namespace Modules\Template\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\Area\Repositories\AreaRepository;
use Modules\Entrust\Repositories\RoleRepository;
use Modules\Entrust\Services\RoleNodeService;
use Modules\Entrust\Utilities\SessionManager;
use Modules\Shop\Repositories\ShopRepository;
use Modules\Template\Http\Requests\Area;
use Modules\User\Repositories\UserRepository;

class TemplateController extends Controller
{
    /** @var RoleNodeService  */
    protected $roleNodeServ;

    public function __construct(RoleNodeService $roleNodeService)
    {
        $this->roleNodeServ = $roleNodeService;
    }

    public function index()
    {
        if (SessionManager::isLogin()) {
            return $this->home();
        }
        return $this->login();
    }

    public function login()
    {
        return view('template::login');
    }

    public function home()
    {
        return $this->render('index');
    }

    public function permission()
    {
        $roleNode = $this->roleNodeServ->getAllRoleAndNode();
        return $this->render('permission', $roleNode);
    }

    public function account()
    {
        $userRepo = app()->make(UserRepository::class);
        $user = $userRepo->getPaginationWithRole();
        $roleRepo = app()->make(RoleRepository::class);
        $role = $roleRepo->getAllExceptAdmin();
        return $this->render('account', [
            'user' => $user,
            'role' => $role,
        ]);
    }

    public function role()
    {
        $roleRepo = app()->make(RoleRepository::class);
        $role = $roleRepo->getPagination();
        return $this->render('role', [
            'role' => $role,
        ]);
    }

    public function area(Area $request)
    {
        $areaRepo = app()->make(AreaRepository::class);
        $area = $areaRepo->getPaginationWithIdOrNull($request->input('id'));
        return $this->render('area', [
            'area' => $area,
            'parameter' => $request->except('page'),
            'id' => $request->input('id'),
            'name' => $request->input('name'),
        ]);
    }

    public function shop()
    {
        $shopRepo = app()->make(ShopRepository::class);
        $shop = $shopRepo->getPagination();
        return $this->render('shop', [
            'shop' => $shop,
        ]);
    }

    private function render(string $tag, array $exData = [])
    {
        $menu = $this->getMenu();
        $data = [
            'menu' => $menu,
        ];
        if (count($exData) > 0) {
            $data = array_merge($exData, $data);
        }
        return view('template::' . $tag, $data);
    }

    private function getMenu()
    {
        $data = $this->roleNodeServ->getNodesByRole();
        $menu = [];
        foreach ($data as $datum) {
            if (is_null($datum->parent_id)) {
                $menu[$datum->id] = $datum;
            } else {
                if (!array_key_exists($datum->parent_id, $menu)) {
                    continue;
                }
                if (is_null($menu[$datum->parent_id]->children)) {
                    $menu[$datum->parent_id]->children = [];
                }
                $menu[$datum->parent_id]->children =
                    array_merge($menu[$datum->parent_id]->children, [$datum->id => $datum]);
            }
        }
        return $menu;
    }
}
