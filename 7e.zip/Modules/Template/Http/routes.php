<?php

Route::group(['middleware' => 'api'], function () {
    //-------------------------------------------------//
    //                   版面呈現
    //-------------------------------------------------//
    Route::group([
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        Route::get('/', 'TemplateController@index');
        Route::get('/login', 'TemplateController@login');
        Route::group(['middleware' => 'login'], function () {
            Route::get('/home', 'TemplateController@home');
        });
        Route::group(['middleware' => 'permission'], function () {
            // 權限設定
            Route::get('/permission', 'TemplateController@permission');
            Route::get('/account', 'TemplateController@account');
            Route::get('/role', 'TemplateController@role');
            Route::get('/area', 'TemplateController@area');
            Route::get('/shop', 'TemplateController@shop');
        });
    });

    //-------------------------------------------------//
    //                   資料處理
    //-------------------------------------------------//
    Route::group([
        'prefix' => 'entrust',
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        /* 不需要權限的入口 */
        Route::post('login', 'EntrustController@login');
        Route::get('logout', 'EntrustController@logout');
    });

    Route::group([
        'prefix' => 'account',
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        /* 需完整權限 (登入、角色的節點權限) */
        Route::group(['middleware' => 'permission',], function () {
            // 權限設定
            Route::post('create', 'AccountController@create');
            Route::post('update', 'AccountController@update');
        });
    });

    Route::group([
        'prefix' => 'role',
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        /* 需完整權限 (登入、角色的節點權限) */
        Route::group(['middleware' => 'permission',], function () {
            // 權限設定
            Route::post('create', 'RoleController@create');
            Route::post('update', 'RoleController@update');
            Route::get('delete', 'RoleController@delete');
        });
    });

    Route::group([
        'prefix' => 'area',
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        /* 需完整權限 (登入、角色的節點權限) */
        Route::group(['middleware' => 'permission',], function () {
            // 權限設定
            Route::post('create', 'AreaController@create');
            Route::post('update', 'AreaController@update');
            Route::get('delete', 'AreaController@delete');
        });
    });

    Route::group([
        'prefix' => 'shop',
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        /* 需完整權限 (登入、角色的節點權限) */
        Route::group(['middleware' => 'permission',], function () {
            // 權限設定
            Route::post('create', 'ShopController@create');
            Route::post('update', 'ShopController@update');
            Route::get('delete', 'ShopController@delete');
        });
    });


    //-------------------------------------------------//
    //                 ajax 資料處理
    //-------------------------------------------------//
    Route::group([
        'prefix' => 'api/system',
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        /* 需完整權限 (登入、角色的節點權限) */
        Route::group(['middleware' => 'permission',], function () {
            // 權限設定
            Route::post('permission/update', 'SystemController@permissionUpdate');
        });
    });

    Route::group([
        'prefix' => 'api/area',
        'namespace' => 'Modules\Template\Http\Controllers'
    ], function () {
        /* 需完整權限 (登入、角色的節點權限) */
        Route::group(['middleware' => 'permission',], function () {
            // 權限設定
            Route::post('search/fuzzy', 'AreaController@getByNameWithParentData');
        });
    });
});
