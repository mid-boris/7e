@extends('adminlte::layouts.master')

@section('title', 'Page Title')
