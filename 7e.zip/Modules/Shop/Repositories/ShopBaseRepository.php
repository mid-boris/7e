<?php

namespace Modules\Shop\Repositories;

use Modules\Base\Contract\Repository\BaseRepository;

class ShopBaseRepository extends BaseRepository
{
    public function __construct()
    {
        parent::__construct();
    }
}
