<?php

namespace Modules\Shop\Entities;

use Modules\Base\Entities\BaseModel;

class ShopBaseModel extends BaseModel
{
}
