<?php

namespace Modules\Entrust\Entities;

use Modules\Base\Entities\BaseModel;

abstract class EntrustBaseModel extends BaseModel
{
}
