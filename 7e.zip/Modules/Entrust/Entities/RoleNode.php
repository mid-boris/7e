<?php

namespace Modules\Entrust\Entities;

use Modules\Base\Entities\BaseModel;

class RoleNode extends BaseModel
{
    protected $table = 'role_node';

    protected $fillable = [];
}
