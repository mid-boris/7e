<?php
namespace Modules\Entrust\Utilities;

use Session;

class SessionManager
{
    public static function getRole() : array
    {
        return Session::get('user.role.0');
    }

    public static function getRoleId() : int
    {
        return Session::get('user.role.0.id');
    }

    public static function getUser() : array
    {
        return Session::get('user');
    }

    public static function isLogin() : bool
    {
        return Session::has('user');
    }

    public static function isAdmin() : bool
    {
        return Session::get('user.role.0.name') == 'admin';
    }
}
