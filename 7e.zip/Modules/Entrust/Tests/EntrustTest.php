<?php

namespace Modules\Entrust\Tests;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class EntrustTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testExample()
    {
        $this->assertTrue(true);
    }
}
