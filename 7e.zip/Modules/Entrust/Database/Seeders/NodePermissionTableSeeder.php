<?php

namespace Modules\Entrust\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Entrust\Services\NodePermissionService;

class NodePermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        /** @var NodePermissionService $nodePmServ */
        $nodePmServ = app()->make(NodePermissionService::class);
        $nodePmServ->addUriPermissionToNode('/permission', '系統設置.權限管理');
        $nodePmServ->addUriPermissionToNode('/api/system/permission/update', '系統設置.權限管理');
        $nodePmServ->addUriPermissionToNode('/account', '系統設置.帳號管理');
        $nodePmServ->addUriPermissionToNode('/account/create', '系統設置.帳號管理');
        $nodePmServ->addUriPermissionToNode('/account/update', '系統設置.帳號管理');
        $nodePmServ->addUriPermissionToNode('/role', '系統設置.角色管理');
        $nodePmServ->addUriPermissionToNode('/role/create', '系統設置.角色管理');
        $nodePmServ->addUriPermissionToNode('/role/update', '系統設置.角色管理');
        $nodePmServ->addUriPermissionToNode('/role/delete', '系統設置.角色管理');

        $nodePmServ->addUriPermissionToNode('/area', '資料設置.地區管理');
        $nodePmServ->addUriPermissionToNode('/area/create', '資料設置.地區管理');
        $nodePmServ->addUriPermissionToNode('/area/update', '資料設置.地區管理');
        $nodePmServ->addUriPermissionToNode('/area/delete', '資料設置.地區管理');

        $nodePmServ->addUriPermissionToNode('/shop', '資料設置.商家管理');
        $nodePmServ->addUriPermissionToNode('/shop/create', '資料設置.商家管理');
        $nodePmServ->addUriPermissionToNode('/shop/update', '資料設置.商家管理');
        $nodePmServ->addUriPermissionToNode('/shop/delete', '資料設置.商家管理');
        $nodePmServ->addUriPermissionToNode('/api/area/search/fuzzy', '資料設置.商家管理');
    }
}
