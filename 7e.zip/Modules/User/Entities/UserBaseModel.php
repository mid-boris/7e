<?php

namespace Modules\User\Entities;

use Modules\Base\Entities\BaseModel;

/**
 * Class UserBaseModel
 * @package Modules\User\Entities
 */
class UserBaseModel extends BaseModel
{
}
