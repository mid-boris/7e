<?php

namespace Modules\User\Services;

abstract class UserBaseService
{
}
