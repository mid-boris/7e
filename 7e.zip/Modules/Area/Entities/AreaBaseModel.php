<?php

namespace Modules\Area\Entities;

use Modules\Base\Entities\BaseModel;

class AreaBaseModel extends BaseModel
{
}
