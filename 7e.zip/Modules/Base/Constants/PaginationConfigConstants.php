<?php

namespace Modules\Base\Constants;

class PaginationConfigConstants
{
    const PAGE_NAME = 'page';
    const PERPAGE_NAME = 'perpage';
}
