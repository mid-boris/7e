<?php

namespace Modules\Base\Constants;

class ConnectionConfigConstants
{
    const MAIN_CONNECTION_NAME = '7e_connection';
}
