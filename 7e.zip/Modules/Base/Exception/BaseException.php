<?php
namespace Modules\Base\Exception;

use Exception;

class BaseException extends Exception
{
}
